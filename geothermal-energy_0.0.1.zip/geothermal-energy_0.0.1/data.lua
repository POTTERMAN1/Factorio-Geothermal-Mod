require("prototypes/entities/geo_pumpjack")
require("prototypes/items/geo_pumpjack")
require("prototypes/resources/geothermal_source")